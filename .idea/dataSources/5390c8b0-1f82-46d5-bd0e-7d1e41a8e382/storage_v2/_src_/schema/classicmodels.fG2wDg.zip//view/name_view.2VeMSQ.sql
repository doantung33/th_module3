create definer = root@localhost view name_view as
select `classicmodels`.`employees`.`employeeNumber` AS `employeeNumber`,
       `classicmodels`.`employees`.`lastName`       AS `lastName`,
       `classicmodels`.`employees`.`firstName`      AS `firstName`
from `classicmodels`.`employees`;

